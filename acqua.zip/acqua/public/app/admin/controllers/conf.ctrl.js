/**
 * AngularJS Application
 * @author Arthur Costa <root.arthur@gmail.com>
 */
angular.module('mangueApp')
.controller('ConfCtrl', function ($scope, $rootScope, $state, $timeout, $location, $localStorage, ngToast) {
    // VAR ROOT
    $rootScope.loading = true;
    
});