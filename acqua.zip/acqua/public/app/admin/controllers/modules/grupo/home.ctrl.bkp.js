/**
 * AngularJS Application
 * @author Arthur Costa <root.arthur@gmail.com>
 */
angular.module('mangueApp')
.controller('GrupoHomeCtrl', function( $scope ,$state, $rootScope, $timeout, $compile, $q, ngToast, Modal, DTOptionsBuilder, DTColumnBuilder, PagesSrv ) { //GrupoHomeSrv
    
    $scope.templateModal = '/tpls/modules/grupo/modal/home.mod.html'


    $scope.edit = function(id) {
        return Modal.openModal({
                templateUrl: $scope.templateModal,
                title: 'Editar '+$scope.title,
                size: 'lg',
                callback: function($scope) {
                    $scope.title = 'Editar '+ $scope.title;
                    // Fuso.request(function(response){
                    //     $scope.timezones = response;
                    // });
                    // $scope.fuso = Fuso.show({id: id});
                }
            }
        );
    };

    
    $scope.dtOptions = DTOptionsBuilder.fromFnPromise(function() {
        var defer = $q.defer();
        PagesSrv.get(function(response){
            defer.resolve(response.data);
            return response.data;
        });
        return defer.promise;
    })
    // .withPaginationType('simple_numbers')
    // .withDOM('frtip')
    .withBootstrap()
    .withBootstrapOptions({
            TableTools: {
                classes: {
                    container: 'btn-group',
                    buttons: {
                        normal: 'btn btn-danger'
                    }
                }
            },
            ColVis: {
                classes: {
                    masterButton: 'btn btn-primary'
                }
            },
            pagination: {
                classes: {
                    ul: 'pagination pagination-sm'
                }
            }
        })

        // Add ColVis compatibility
       // .withColVis()

        // Add Table tools compatibility
        .withTableTools('components/datatables-tabletools/swf/copy_csv_xls_pdf.swf')
        .withTableToolsButtons([
            'copy',
            'print', {
                'sExtends': 'collection',
                'sButtonText': 'Save',
                'aButtons': ['csv', 'xls', 'pdf']
            }
        ])
    // Add Bootstrap compatibility
    .withPaginationType('full_numbers')
    .withOption('responsive', true)
    .withOption('createdRow', createdRow)
    .withLanguageSource('languages/i18n/Portuguese-Brasil.json');

    $scope.dtColumns = [
        DTColumnBuilder.newColumn('id').withTitle('ID'),
        DTColumnBuilder.newColumn('name').withTitle('Nome'),
        DTColumnBuilder.newColumn(null).withTitle('Ações').notSortable()
            .renderWith(actionsHtml)
    ];

    $scope.data = {};
    $scope.dtInstance = {};
    $scope.reloadData = reloadData;

    function reloadData () {
        var resetPaging = true;
        $scope.dtInstance.reloadData( callback, resetPaging);
    };

    function callback(json) {
        console.log(json);
    }

    function createdRow(row, data, dataIndex) {
        // Recompiling so we can bind Angular directive to the DT
        $compile(angular.element(row).contents())($scope);
    }
    function actionsHtml(data, type, full, meta) {
        $scope.data[data.id] = data;
        return '<button class="btn btn-sm btn-warning" ng-click="edit(data[' + data.id + '])">' +
            '   <i class="fa fa-edit"></i>' +
            '</button>&nbsp;' +
            '<button class="btn btn-sm btn-danger" ng-click="delete(data[' + data.id + '])" )"="">' +
            '   <i class="fa fa-trash-o"></i>' +
            '</button>';
    }

    //$scope.dtsOptions = DTOptionsBuilder.fromSource( getPages ).withPaginationType('full_numbers');
    //$scope.dtsOptions = DTOptionsBuilder.fromFnPromise( getPages ).withPaginationType('full_numbers');

    // function getPages(){
    //     return PagesSrv.get(function(response){
    //         return response.data;
    //     });
    // }
    // $scope.dataTable = DataTables.get({

    // })
    // $scope.getFusoList = SmartTable.get({
    //     param: function(){
    //         return null;
    //     },
    //     service: function() {
    //         return Fuso;
    //     },
    //     callback: function(response) {
    //         $scope.fusos = response.data;
    //     },
    //     isLoading: function(isLoading) {
    //         $scope.isLoading = isLoading;
    //     }
    // });


//    $scope.getStockCondos = function( id )
//    {
//        // GET PRODUTOS
//        StockCondosService.getArray({cmd:'get', id: id}, function(response){
//            angular.forEach(response, function(value) {
//                value.adicionar = 0;
//            });                        
//            $scope.products = response;
//        });
//    }
    
});
