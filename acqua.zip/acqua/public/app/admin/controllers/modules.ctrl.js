/**
 * AngularJS Application
 * @author Arthur Costa <root.arthur@gmail.com>
 */
angular.module('mangueApp')
.controller('ModulesCtrl', function ($scope, $rootScope, $state, $timeout, $location, $localStorage, ngToast) {
    // VAR ROOT
    // console.log('Main ...')
    $rootScope.loading = true;
    // ACTIVE NAVEGATE
    // $scope.isActive = function (path) {
    //     return ($location.path().substr(0, path.length) === path) ? 'active' : '';
    // };

    
});