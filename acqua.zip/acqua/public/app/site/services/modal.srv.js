/**
 * AngularJS Application
 * @author Arthur Costa <root.arthur@gmail.com>
 */
angular.module('acquaApp')
.service('Modal', function($uibModal, $state) {
    noBack = true;
    
    this.openModal = function(options) {
        
        $uibModal.open({
            templateUrl: options.templateUrl,
            size: 'lg',
            //scope: scope,
            controller: function($scope, $modalInstance) {
                
                $scope.title = options.title;
                //$scope.dataForm.name = 'asd';// = options.data;
                
                //options.show($scope);
                //$scope.show(1);
                
                $scope.$on('$stateChangeStart', function(e, toState, toParams, fromState, fromParams) {
                    $modalInstance.close({toState: toState});
                    console.log(toState.url);
                });
                
                $scope.ok = function () {
                    $modalInstance.close($scope.selected.item);
                };
                
                $scope.cancel = function () {
                    $modalInstance.dismiss('cancel');
                    //$state.go('^', 'listar');
                };
                
                if (options.callback) {
                    options.callback($scope);
                }
    
            },
            resolve: {
                params: function() {
                    return options.params;
                }
            },
            onEnter: function($scope, $modalInstance) {
                $scope.cancel = function() {
                    $modalInstance.dismiss('cancel');
                };
            }
        }).result.then(function(result, $modalInstance) {
            console.log(result.toState.url);
            console.log("close");
        }, function() {
            //$state.go('^');
        });
    };
    
});