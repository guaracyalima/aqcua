/**
 * AngularJS Application
 * @author Arthur Costa <root.arthur@gmail.com>
 */
angular.module('acquaApp')
.factory('AcquariusSrv', function (AbsSrv) {
    
    AbsSrv.uri('/api/acquarius/acquarius.json');

    return AbsSrv.getRest();
    
});
