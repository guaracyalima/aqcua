/**
 * AngularJS Application
 * @author Arthur Costa <root.arthur@gmail.com>
 */
angular.module('acquaApp')
.factory('FitSrv', function (AbsSrv) {
    
    AbsSrv.uri('/api/acquafitness/fit.json');

    return AbsSrv.getRest();
    
});
