/**
 * AngularJS Application
 * @author Arthur Costa <root.arthur@gmail.com>
 */
angular.module('acquaApp')
.controller('HomeAcquaMedCtrl', function( $scope ,$state, $timeout, $rootScope, $location, $timeout, Modal, MedSrv, MedServicesSrv, MedBlogSrv) {
    // VAR ROOT
    $rootScope.loading = true;
    $rootScope.acLetter = '';
    $rootScope.showModal = '';
    // VAR LOCAL
    $scope.slides = {};
    $scope.pages = {};
    $scope.medCat = {};
    $scope.servicos = {};
    $scope.templateBlog = 'assets/tpl/acquamed/modal/blog.html';
    
    // PAGE 
    MedSrv.get(function(response){
        $scope.slides = response.med.slides;
        $scope.pages = response.med.pages;
    });

    MedServicesSrv.get(function(response){
        $scope.medCat = response.services.especialidades.lists;
        $scope.medSer = response.services.servicos;
    })

    MedBlogSrv.get(function(response){
        $scope.medBlog = response.med.blog;
    })
    
    
    // Mostra um existente
    // this.showBlog = function() {
    //     // console.debug( id )
    //     console.debug('teste');
    //     // return Modal.openModal({
    //     //         templateUrl: $scope.templateBlog,
    //     //         title: 'Blog',
    //     //         callback: function($scope) {
    //     //            //$scope.regra =  Regra.show({id: id});
    //     //         }
    //     //     }
    //     //);
    // };
    
    // CONF CAROUSEL
    $scope.sliderOption = {
                                rtl:true,
                                loop:true,
                                margin:40,
                                autoplay: true,
                                autoplayHoverPause: true,
                                autoplaySpeed: 1500,
                                responsiveClass:true,
                                navigation : true,
                                nav: true,
                                navText : ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>'],
                                responsiveClass:true,
                                responsive: {
                                                0: {
                                                    items: 1
                                                },
                                                600: {
                                                    items: 2
                                                },
                                                1000: {
                                                    items: 4
                                                }
                                            }
                            };
    // CONF NAV
    $scope.navOption = {
                                rtl:false,
                                loop:false,
                                dots: false,
                                margin:1,
                                responsiveClass:true,
                                navigation : true,
                                nav: true,
                                navText : ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>'],
                                responsiveClass:true,
                                responsive: {
                                                0: {
                                                    items: 4
                                                },
                                                600: {
                                                    items: 6
                                                },
                                                1000: {
                                                    items: 8
                                                }
                                            }
                        };

    // CONF BLOG
    $scope.blogOption = {
                                rtl:false,
                                loop:false,
                                margin:15,
                                video:true,
                                videoHeight: 240,
                                lazyLoad:true,
                                responsiveClass:true,
                                navigation : true,
                                nav: true,
                                navText : ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>'],
                                responsiveClass:true,
                                responsive: {
                                                0: {
                                                    items: 1
                                                },
                                                600: {
                                                    items: 2
                                                },
                                                1000: {
                                                    items: 3
                                                }
                                            }
                            };
    
    
    // BTN FILTER
    $scope.allLetter = function( letter )
    {
        $rootScope.acLetter = '';
        // $scope.servicos = {};
    }

    // ACT
    $scope.getMedServices = function( val )
    {
        var ser = {};
        angular.forEach( $scope.medSer, function( col ){
            if( val === col.cat_id ){
                ser = col;
            }
        });
        $timeout(function(){
            $scope.servicos = ser;
        },true);
    }

});