/**
 * AngularJS Application
 * @author Arthur Costa <root.arthur@gmail.com>
 */
angular.module('acquaApp')
.controller('HomeAcquaFitnessCtrl', function( $scope ,$state, $timeout, $rootScope, $location, $timeout, FitSrv, FitBlogSrv) {
    // VAR ROOT
    $rootScope.loading = true;
    // VAR LOCAL
    $scope.slides = {},
    $scope.pages = {};
    
    // NAV BAR
    FitSrv.get(function(response){
        $scope.slides = response.fit.slides;
        $scope.pages = response.fit.pages;
    });
    // BLOG
    FitBlogSrv.get(function(response){
        $scope.fitBlog = response.fit.blog;
    });
    // CONF BLOG
    $scope.blogOption = {
                                rtl:false,
                                loop:false,
                                margin:15,
                                responsiveClass:true,
                                navigation : true,
                                nav: true,
                                navText : ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>'],
                                responsiveClass:true,
                                responsive: {
                                                0: {
                                                    items: 1
                                                },
                                                600: {
                                                    items: 2
                                                },
                                                1000: {
                                                    items: 3
                                                }
                                            }
                            };
});