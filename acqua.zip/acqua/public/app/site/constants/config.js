/**
 * AngularJS Application
 * @author Arthur Costa <root.arthur@gmail.com>
 */
angular.module('acquaApp')
// ROUTER
.constant('URI_API', {
    sys:      'http://localhost/acqua2',
});
