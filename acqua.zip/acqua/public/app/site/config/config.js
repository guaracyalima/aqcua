/**
 * AngularJS Application
 * @author Arthur Costa <root.arthur@gmail.com>
 */

'use strict';

angular.module('acquaApp')
.run(function($rootScope, $templateCache, $timeout) {

    // ROOT VAR        
    $rootScope.isNavCollapsed = false;
    $rootScope.dataCartShop = {};
    $rootScope.alpNav = [
        {value:'a'}, {value:'b'}, {value:'c'}, {value:'d'}, {value:'e'}, {value:'f'}, {value:'g'}, {value:'h'}, 
        {value:'i'}, {value:'j'}, {value:'k'}, {value:'l'}, {value:'m'}, {value:'n'}, {value:'o'}, {value:'p'}, 
        {value:'q'}, {value:'r'}, {value:'s'}, {value:'t'}, {value:'u'}, {value:'v'}, {value:'w'}, {value:'x'}, 
        {value:'y'}, {value:'z'}
    ]
    $rootScope.confMaps = {};
    
    // $rootScope.$on('$viewContentLoaded', function() {
    //     $templateCache.removeAll();
    // });
    //ROUTER CHANGE START
    $rootScope.$on('$routeChangeStart', function(event, next, current) {
        if (typeof(current) !== 'undefined'){
            $templateCache.remove(current.templateUrl);
        }
    });

    function loadStorage( storage ) {
        // ... just sit back and bask in the glory of dependency-injection.
    }


    // FILTER 
    // $rootScope.acLetter = '';
    // $rootScope.activateLetter = function( letter )
    // {
    //     console.log(letter);
    //     $rootScope.acLetter = letter;
    // }

    // $rootScope.addCart = function($event, prod){
    //     //$event.currentTarget
    //     // ANIMATE BTN
    //     var tag  = angular.element($event.target)
    //     tag.addClass('add').find('i').removeClass('fa-shopping-cart').addClass('fa-plus');
    //     $timeout(function(){
    //         tag.removeClass('add').find('i').removeClass('fa-plus').addClass('fa-shopping-cart');
    //     },500);
    //     $('.cart-container').cart();
    //     //$(element).parallaxHeader(options); 
    //     //angular.element('.cart-container').
    // }


})
// .run(function($rootScope, $templateCache) {
//    $rootScope.$on('$viewContentLoaded', function() {
//       $templateCache.removeAll();
//    });
// });

// I am the localStorage key that will be used to persist data for this demo.
angular.module('acquaApp').value( "storageKey", "gigants_app" );