require('./angular-locale_ak-gh');
module.exports = 'ngLocale';
