<?php

namespace Modules\Admin\Entities;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Pages extends Model
{
    protected $fillable = [
        'id',
        'seg_id',
        'name',
        'title',
        'subtitle'
    ];
    
    protected $dates = ['deleted_at'];
    
    public $timestamps = false;
    
    protected $table = "pages";
    
}
