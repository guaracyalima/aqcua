<?php

namespace Modules\Admin\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class HealthServices extends Model
{
    protected $fillable = [
        'id',
        'hs_id',
        'name',
        'img',
        'desc'
    ];
    
    protected $dates = ['deleted_at'];
    
    protected $table = "health_services";
}
