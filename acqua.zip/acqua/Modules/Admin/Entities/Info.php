<?php

namespace Modules\Admin\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Info extends Model
{
    protected $fillable = [
        'id',
        'name'
    ];
    
    protected $dates = ['deleted_at'];
    
    protected $table = "info";
    
}
