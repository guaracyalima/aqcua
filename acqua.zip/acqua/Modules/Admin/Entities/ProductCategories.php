<?php

namespace Modules\Admin\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductCategories extends Model
{
    protected $fillable = [
        'id',
        'seg_id',
        'title',
        'desc',
        'icon'
    ];
    
    protected $dates = ['deleted_at'];
    
    protected $table = "product_categories";
}
