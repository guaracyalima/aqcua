<?php

namespace Modules\Admin\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ContentPages extends Model
{
    protected $fillable = [
        'id',
        'page_id',
        'title',
        'subtitle',
        'content',
        'img',
        'link'
    ];
    
    protected $dates = ['deleted_at'];
    
    public $timestamps = false;
    
    protected $table = "content_pages";
}
