<?php

namespace Modules\Admin\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Teams extends Model
{
    protected $fillable = [
        'id',
        'group_id',
        'name',
        'initials',
        'crm',
        'desc',
        'img'
    ];
    
    protected $dates = ['deleted_at'];
    
    protected $table = "teams";
}
