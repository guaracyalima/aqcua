<?php

namespace Modules\Admin\Entities;

use Illuminate\Database\Eloquent\Model;

class TeamGroups extends Model
{
    protected $fillable = [
        'id',
        'name',
        'desc'
    ];
    
    protected $dates = ['deleted_at'];
    
    protected $table = "team_groups";
}
