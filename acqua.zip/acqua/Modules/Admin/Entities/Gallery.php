<?php

namespace Modules\Admin\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Gallery extends Model
{
    protected $fillable = [
        'page_id',
        'title',
        'subtitle',
        'content',
        'link',
        'img'
    ];
    
    protected $dates = ['deleted_at'];
    
    protected $table = "gallery";
}
