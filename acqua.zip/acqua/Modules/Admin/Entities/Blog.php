<?php

namespace Modules\Admin\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Blog extends Model
{
    protected $fillable = [
        'id',
        'page_id',
        'title',
        'subtitle',
        'content',
        'author',
        'img',
        'link',
        'video'
    ];
    
    protected $dates = ['deleted_at'];
    
    protected $table = "blog";
}
